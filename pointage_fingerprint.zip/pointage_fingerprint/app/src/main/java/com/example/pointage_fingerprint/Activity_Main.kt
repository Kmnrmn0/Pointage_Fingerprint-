package com.example.pointage_fingerprint

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class Activity_Main : AppCompatActivity() {

    private lateinit var statusTextView: TextView
    private lateinit var btnPointage: Button
    private lateinit var btnGestionMembres: Button
    private lateinit var btnRapports: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialiser les composants de l’interface
        statusTextView = findViewById(R.id.txt_1)
        btnPointage = findViewById(R.id.btn_pointage)
        btnGestionMembres = findViewById(R.id.btn_gestion_membres)
        btnRapports = findViewById(R.id.btn_rapports)

        // Action pour le bouton Pointage
        btnPointage.setOnClickListener {
            // Démarrer l'activité de pointage (exemple)
            val intent = Intent(this, Activity_fingerprint::class.java)
            startActivity(intent)
        }

        // Action pour le bouton Gestion des Membres
        btnGestionMembres.setOnClickListener {
            val intent = Intent(this, Member::class.java)
            startActivity(intent)
            statusTextView.text = "Gestion des membres sélectionnée"
        }

        // Action pour le bouton Rapports
        btnRapports.setOnClickListener {
            val intent = Intent(this, RapportsActivity::class.java)
            startActivity(intent)
            statusTextView.text = "Rapports sélectionné"
        }
    }
}
