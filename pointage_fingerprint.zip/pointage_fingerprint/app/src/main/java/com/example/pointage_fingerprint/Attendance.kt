package com.example.pointage_fingerprint

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.PrimaryKey

class Attendance {
    @Entity(
        tableName = "attendances",
        foreignKeys = [ForeignKey(
            entity = Member::class,
            parentColumns = arrayOf("id"),
            childColumns = arrayOf("member_id"),
            onDelete = ForeignKey.CASCADE // Si un membre est supprimé, toutes ses présences le sont aussi
        )]
    )
    data class Attendance(
        @PrimaryKey(autoGenerate = true) val id: Int = 0, // ID auto-généré par défaut
        @ColumnInfo(name = "member_id") val memberId: Int, // Clé étrangère vers l'entité "Member"
        @ColumnInfo(name = "date") val date: String, // Date de pointage (format YYYY-MM-DD recommandé)
        @ColumnInfo(name = "status") val status: String // "Présent" ou "Absent"
    )
}