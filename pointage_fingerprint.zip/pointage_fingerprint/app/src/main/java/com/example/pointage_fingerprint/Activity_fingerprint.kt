package com.example.pointage_fingerprint

import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.concurrent.Executor

class Activity_fingerprint : AppCompatActivity() {

    private lateinit var biometricPrompt: BiometricPrompt
    private lateinit var executor: Executor
    private lateinit var statusTextView: TextView
    private lateinit var databaseHelper: DatabaseHelper

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_fingerprint)

        // Initialize components
        statusTextView = findViewById(R.id.txt_status)
        executor = ContextCompat.getMainExecutor(this)
        databaseHelper = DatabaseHelper(this)  // Créez une instance de DatabaseHelper

        // Biometric prompt setup
        biometricPrompt = BiometricPrompt(this, executor,
            object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    statusTextView.text = "Authentification réussie!"

                    // Ajout de la logique de pointage en temps réel
                    val timestamp = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(java.util.Date())
                    val success = databaseHelper.enregistrerPointage(timestamp)

                    if (success) {
                        Toast.makeText(this@Activity_fingerprint, "Pointage enregistré!", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this@Activity_fingerprint, "Erreur d'enregistrement du pointage.", Toast.LENGTH_SHORT).show()
                    }
                }

                override fun onAuthenticationFailed() {
                    super.onAuthenticationFailed()
                    statusTextView.text = "Authentification échouée. Essayez à nouveau."
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    statusTextView.text = "Erreur : $errString"
                }
            })

        // Prompt info
        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("Pointage par empreinte digitale")
            .setDescription("Utilisez votre empreinte pour pointer.")
            .setNegativeButtonText("Annuler")
            .build()

        // Lancer l'authentification par empreinte
        biometricPrompt.authenticate(promptInfo)
    }
}
