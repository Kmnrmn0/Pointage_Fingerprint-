package com.example.pointage_fingerprint

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

class Member {

    @Entity(tableName = "members")
    data class Member(
        @PrimaryKey(autoGenerate = true) val id: Int = 0, // Par défaut, l'ID commence à 0, auto-généré
        @ColumnInfo(name = "first_name") val firstName: String,
        @ColumnInfo(name = "last_name") val lastName: String,
        @ColumnInfo(name = "contact") val contact: String,
        @ColumnInfo(name = "gender") val gender: String,
        @ColumnInfo(name = "residence") val residence: String,
        @ColumnInfo(name = "fingerprint") val fingerprint: String // Stockage sécurisé des empreintes
    )
}