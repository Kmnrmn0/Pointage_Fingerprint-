package com.example.pointage_fingerprint

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.itextpdf.kernel.pdf.PdfDocument
import com.itextpdf.kernel.pdf.PdfWriter
import com.itextpdf.layout.Document
import com.itextpdf.layout.element.Paragraph
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.io.File
import java.io.FileOutputStream

class RapportsActivity : AppCompatActivity() {

    private lateinit var btnGeneratePdf: Button
    private lateinit var btnGenerateExcel: Button
    private lateinit var statusTextView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_genenration_de_rapport) // Corrigé : ajout de la parenthèse fermante

        // Initialiser les composants de l'interface
        btnGeneratePdf = findViewById(R.id.btn_generate_pdf)
        btnGenerateExcel = findViewById(R.id.btn_generate_excel)
        statusTextView = findViewById(R.id.txt_generate_report)

        // Gérer le clic sur le bouton pour générer un PDF
        btnGeneratePdf.setOnClickListener {
            generatePdfReport()
        }

        // Gérer le clic sur le bouton pour générer un Excel
        btnGenerateExcel.setOnClickListener {
            generateExcelReport()
        }
    }

    private fun generatePdfReport() {
        // Chemin où le PDF sera enregistré
        val pdfFile = File(filesDir, "report.pdf")
        try {
            // Création du document PDF
            val writer = PdfWriter(pdfFile)
            val pdfDoc = PdfDocument(writer)
            val document = Document(pdfDoc)

            // Ajout de contenu au PDF
            document.add(Paragraph("Génération de rapport PDF"))
            document.add(Paragraph("Ceci est un exemple de rapport PDF."))

            document.close() // Ferme le document
            Toast.makeText(this, "PDF généré : ${pdfFile.absolutePath}", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Erreur lors de la génération du PDF : ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun generateExcelReport() {
        // Chemin où le fichier Excel sera enregistré
        val excelFile = File(filesDir, "report.xlsx")
        try {
            // Création du classeur Excel
            val workbook = XSSFWorkbook()
            val sheet = workbook.createSheet("Rapport")

            // Ajout de contenu à l'Excel
            val row = sheet.createRow(0)
            row.createCell(0).setCellValue("Titre")
            row.createCell(1).setCellValue("Description")
            val dataRow = sheet.createRow(1)
            dataRow.createCell(0).setCellValue("Génération de rapport Excel")
            dataRow.createCell(1).setCellValue("Ceci est un exemple de rapport Excel.")

            // Écriture du fichier Excel
            val fileOutputStream = FileOutputStream(excelFile)
            workbook.write(fileOutputStream)
            workbook.close() // Ferme le classeur
            fileOutputStream.close() // Ferme le flux de sortie

            Toast.makeText(this, "Excel généré : ${excelFile.absolutePath}", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Erreur lors de la génération de l'Excel : ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }
}