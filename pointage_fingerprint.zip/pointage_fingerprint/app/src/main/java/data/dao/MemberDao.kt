package data.dao

import androidx.room.*
import com.example.pointage_fingerprint.Member
import kotlinx.coroutines.flow.Flow

class MemberDao {

    @Dao
    interface MemberDao {

        // Insérer ou mettre à jour un membre
        @Insert(onConflict = OnConflictStrategy.REPLACE)
        suspend fun insertMember(member: Member)

        // Obtenir un membre par son ID
        @Query("SELECT * FROM members WHERE id = :id")
        suspend fun getMemberById(id: Int): Member?

        // Récupérer tous les membres en temps réel avec Flow
        @Query("SELECT * FROM members")
        fun getAllMembers(): Flow<List<Member>>

        // Supprimer un membre par son ID
        @Delete
        suspend fun deleteMember(member: Member)

        // Supprimer tous les membres
        @Query("DELETE FROM members")
        suspend fun deleteAllMembers()

        // Mettre à jour les informations d'un membre
        @Update
        suspend fun updateMember(member: Member)
    }
}