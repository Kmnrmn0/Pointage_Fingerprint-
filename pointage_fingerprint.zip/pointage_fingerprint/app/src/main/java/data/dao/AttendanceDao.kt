package data.dao

import androidx.room.*
import com.example.pointage_fingerprint.Attendance
import kotlinx.coroutines.flow.Flow

class AttendanceDao {

       @Dao
    interface AttendanceDao {

        // Insérer une nouvelle présence
        @Insert(onConflict = OnConflictStrategy.REPLACE)
        suspend fun insertAttendance(attendance: Attendance.Attendance)

        // Obtenir la présence d'un membre pour une date spécifique
        @Query("SELECT * FROM attendances WHERE member_id = :memberId AND date = :date")
        suspend fun getAttendanceByMemberAndDate(memberId: Int, date: String): Attendance?

        // Récupérer toutes les présences pour un membre
        @Query("SELECT * FROM attendances WHERE member_id = :memberId")
        fun getAttendancesByMember(memberId: Int): Flow<List<Attendance>>

        // Récupérer toutes les présences
        @Query("SELECT * FROM attendances")
        fun getAllAttendances(): Flow<List<Attendance>>

        // Supprimer une présence spécifique
        @Delete
        suspend fun deleteAttendance(attendance: Attendance)

        // Supprimer toutes les présences
        @Query("DELETE FROM attendances")
        suspend fun deleteAllAttendances()

        // Mettre à jour une présence
        @Update
        suspend fun updateAttendance(attendance: Attendance)
    }
}