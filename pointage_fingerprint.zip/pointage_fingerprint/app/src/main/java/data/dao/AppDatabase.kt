package data.dao
import androidx.room.RoomDatabase
import androidx.room.Database
class AppDatabase {
    @Database(entities = [MemberDao::class, AttendanceDao.AttendanceDao::class], version = 1)
    abstract class AppDatabase : RoomDatabase() {
        abstract fun memberDao(): MemberDao
        abstract fun attendanceDao(): AttendanceDao
    }
}